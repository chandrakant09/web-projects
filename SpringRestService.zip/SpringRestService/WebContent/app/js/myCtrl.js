app.controller("myCtrl", function($scope) {
	$scope.firstName = "cn";
	$scope.lastName = "dkd";
  });