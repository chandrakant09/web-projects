package com.restful.model;

public class Register {

}
